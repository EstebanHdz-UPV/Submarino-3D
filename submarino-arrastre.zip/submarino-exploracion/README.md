# Simulador de Submarinos 3D

Simulador de submarino de exploración: se **arma desde cero** con piezas y materiales, se consultan **dos libros** (piezas y materiales), y se **prueba** en escenarios con física realista, incluso con el diseño incompleto.

**Equipo:** Nayma Karina Rodriguez Guevara (2530250) · Enrique Zoe Leon Saldivar (2530265) · Oscar Daniel Purata Martinez (2530285) · Jorge Esteban Hernández Pérez (2530451)
**Metodología:** Kanban (Trello + GitHub) · **Motor:** Babylon.js 9.32 (≥ 9) · **Lenguaje:** JavaScript puro con módulos ES

## Requisitos

- **Node.js 18 o superior** (solo para servir el proyecto en local, no para desarrollar).
- Un navegador moderno con WebGL2 (Chrome, Edge o Firefox).
- **No necesita internet.** Babylon.js ya está en `vendor/babylon/`.

## Ejecutar

```bash
node server.js        # o: npm start
# abrir http://localhost:3000
```

Para usar otro puerto: `PORT=3100 node server.js` (en Windows PowerShell: `$env:PORT=3100; node server.js`).
El servidor escucha solo en `127.0.0.1`.

## Cómo se usa

1. **Libros:** consulta el Libro 1 (piezas y ensamblaje) y el Libro 2 (materiales por escenario y profundidad).
2. **Ensamblaje:** elige un punto de montaje y una pieza. El casco permite elegir material. Las estadísticas se actualizan en vivo (masa, flotabilidad, profundidad de colapso, estabilidad, costo). "Cargar ejemplo" trae un submarino listo.
3. **Pruebas:** elige un escenario y las condiciones (profundidad, velocidad, temperatura, corriente) y pulsa *Iniciar prueba*. Puedes probar aunque falten piezas.
4. **Estrés estructural:** mapa de colores del casco a cualquier profundidad.
5. **Resultados:** dictamen aprobado/no aprobado con causas, métricas y gráficas; *Guardar reporte*.
6. **Piloto manual** (escenario "Piloto manual"): maneja con el teclado y observa el HUD.

### Controles del piloto manual

| Tecla | Acción |
|---|---|
| W / ↑ · S / ↓ | Más / menos empuje · **Espacio** detiene el motor |
| A / ← · D / → | Timón izquierda / derecha (necesita velocidad) |
| Z · C | Desplazamiento lateral |
| E · Q | Llenar lastre (descender) · vaciar lastre (ascender) |
| B · G | Soplar lastre · soltar pesos (emergencia) |
| V · R · H | Cambiar cámara · reiniciar · ayuda |

## Estructura

```
index.html · server.js · manifest.json · package.json
vendor/babylon/      Babylon.js 9.32 + loader glTF (local)
src/core/            SLog, Config, Telemetry, Loop, EventBus
src/modules/         scene · physics · submarine · controls · environment · trials · books · ui
assets/              models (.glb) · textures · icons (.svg)
data/                JSON: física, materiales, piezas, reglas, escenarios, libros, i18n, diseños, kanban
docs/                metodología, objetivos, rúbricas, lecciones, física, bitácora, kanban
```

Detalle de requisitos, cronograma y flujo de trabajo en `docs/`.

## Reglas del proyecto

- Solo JavaScript puro con módulos ES. **Sin frameworks, sin TypeScript, sin bundlers.**
- Modelos solo `.glb`/`.gltf`; imágenes solo PNG/JPG/WebP; iconos solo SVG; datos en JSON.
- Todo se sirve localmente (sin CDN).
- Cada cambio: tarjeta de Trello `SUB-###`, rama `sub-###-nombre`, Pull Request con la plantilla y entrada de bitácora.

## Trabajo pendiente del equipo

- Reemplazar los `.glb` marcadores de `assets/models/` por modelos propios (el cargador los escala a las medidas de cada pieza; el submarino mira hacia **+Z**).
- Validar la física con un submarino real y citar las fuentes de los datos (`docs/FISICA.md`, `CREDITS.md`).
- Sustituir `data/rubrics.json` por la rúbrica oficial.
- Revisar y entender cada módulo antes de pasar su tarjeta a *Terminado*.

## Depuración

En la consola del navegador, `__submarino` da acceso a la aplicación (por ejemplo `__submarino.assembly.stats(__submarino.worldEfectivo(), {tipoAgua:'mar'})`). En *Configuración* se pueden exportar el SLog y la telemetría. La telemetría del servidor queda en `data/telemetry/*.jsonl`.
