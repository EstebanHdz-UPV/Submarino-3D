# Créditos y licencias

| Recurso | Fuente | Licencia |
|---|---|---|
| Babylon.js 9.32.0 (`vendor/babylon/babylon.js`) | https://www.babylonjs.com · paquete npm `babylonjs` | Apache 2.0 (`vendor/babylon/LICENSE.md`) |
| Loader glTF 9.32.0 (`vendor/babylon/babylon.glTFFileLoader.min.js`) | paquete npm `babylonjs-loaders` | Apache 2.0 |
| Iconos SVG (`assets/icons/`) | Dibujados por el equipo (trazos propios) | Propios |
| Modelos `.glb` (`assets/models/`) | **Marcadores** generados con un script; reemplazar por modelos propios | Propios |
| Datos de materiales y piezas | Valores de referencia de fichas técnicas típicas | **Pendiente: citar fuente de cada dato (SUB-024)** |
| Código base y documentación inicial | Generado con ayuda de Claude (Anthropic) y revisado por el equipo | Ver `docs/bitacora/BITACORA.md` |

Agregar aquí cada modelo, textura o dato externo con su fuente y licencia.
