# Tablero Kanban (copia)

La fuente de verdad es el tablero de **Trello**. Esta copia se actualiza con cada export semanal.

> **Importante:** el código base fue generado con ayuda de IA (ver `docs/bitacora/BITACORA.md`). Por eso la mayoría de las tarjetas empiezan en **Verificación**: cada responsable debe revisar, probar y entender su parte antes de pasarla a **Terminado**.

## Backlog (1)
- **SUB-027** Ambientes visuales por escenario — Zoé

## Listo (2)
- **SUB-014** Modelo 3D en .glb (reemplazar marcadores) — Zoé
- **SUB-024** Validación con submarino real — Nayma

## En progreso (1)
- **SUB-020** Documentación — Esteban

## Verificación (32)
- **SUB-001** Estructura base del proyecto — Esteban
- **SUB-002** Librerías locales (Babylon.js 9+ en vendor) — Esteban
- **SUB-003** Configuración, SLog y telemetría — Esteban
- **SUB-004** Escena, luz y niebla — Zoé
- **SUB-005** Bucle principal de paso fijo — Esteban
- **SUB-006** Peso y empuje de Arquímedes — Nayma
- **SUB-007** Lastre base — Esteban
- **SUB-008** Arrastre hidrodinámico — Nayma
- **SUB-009** Masa añadida — Nayma
- **SUB-010** Hélice y aceleración — Oscar
- **SUB-011** Estabilidad CG/CB — Nayma
- **SUB-012** Presión — Nayma
- **SUB-013** Pantalla HUD y sonar — Oscar
- **SUB-015** Atenuación de luz — Zoé
- **SUB-016** Densidad variable — Nayma
- **SUB-017** Corrientes — Nayma
- **SUB-018** Batería y consumo — Oscar
- **SUB-019** Objetivos de misión — Esteban
- **SUB-021** Materiales y esfuerzo del casco (colapso) — Nayma
- **SUB-022** Estadísticas del ensamble y piezas faltantes — Nayma
- **SUB-023** Motor de pruebas y escenarios — Nayma
- **SUB-025** Piezas .glb modulares y ensamblador visual — Zoé
- **SUB-026** Focos, partículas, efectos de daño y mapa de esfuerzo — Zoé
- **SUB-028** Cámaras y reinicio — Oscar
- **SUB-029** Interfaz del constructor y catálogo — Oscar
- **SUB-030** Visores de los Libros 1 y 2 — Oscar
- **SUB-031** Menú de pruebas y pantalla de resultados — Oscar
- **SUB-032** Esquemas JSON de piezas, materiales y reglas — Esteban
- **SUB-033** Contenido de los dos libros — Esteban
- **SUB-034** Guardado y carga de diseños — Esteban
- **SUB-035** Pantalla de Inicio y navegación — Oscar
- **SUB-036** Pantalla de Configuración — Oscar

## Terminado (0)

