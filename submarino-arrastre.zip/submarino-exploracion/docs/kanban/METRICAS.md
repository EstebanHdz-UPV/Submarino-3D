# Métricas de flujo

Se llenan cada viernes con el export de Trello (`docs/kanban/export-AAAA-MM-DD.json`).

| Semana | Tarjetas terminadas (throughput) | Lead time promedio (días) | Cycle time promedio (días) | WIP promedio | Defectos |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |

Definiciones: **lead time** = creación → terminada; **cycle time** = en progreso → terminada; **throughput** = tarjetas terminadas por semana.
