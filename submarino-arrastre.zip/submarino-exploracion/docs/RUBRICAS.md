# Rúbricas

> **Plantilla.** Sustituir por la rúbrica oficial del profesor cuando la tengan (`data/rubrics.json`).

Niveles: 4 = Excelente, 3 = Bueno, 2 = Suficiente, 1 = Insuficiente

| ID | Criterio | Qué se evalúa | Peso (%) |
|---|---|---|---|
| R1 | Stack tecnológico | Babylon.js ≥ 9, JS puro con módulos ES, sin frameworks, sin TypeScript, Node ≥ 18 solo para ejecutar. | 15 |
| R2 | Formatos y recursos | Solo .glb/.gltf, PNG/JPG/WebP y SVG; datos en JSON; manifest.json. | 10 |
| R3 | Funcionamiento sin conexión | Todo se sirve localmente. | 10 |
| R4 | Fidelidad física | Propiedades físicas implementadas en SI y validadas. | 20 |
| R5 | Funcionalidad del simulador | Constructor, libros, pruebas, dictamen, piloto y HUD. | 20 |
| R6 | Trazabilidad | SLog, telemetría y bitácora completas, con uso de IA documentado. | 10 |
| R7 | Metodología Kanban | Tablero en Trello, WIP, DoD, métricas y PR en GitHub. | 10 |
| R8 | Documentación | README, objetivos, rúbricas, lecciones y créditos. | 5 |

Total: 100 %
