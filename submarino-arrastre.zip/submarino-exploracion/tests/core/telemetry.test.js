import test from 'node:test';
import assert from 'node:assert/strict';
import { Telemetry } from '../../src/core/Telemetry.js';

test('telemetría limita el buffer y aplica intervalo de muestreo', () => {
  const t = new Telemetry({ intervalMs: 100, batchSize: 999, maxBuffer: 2 });
  assert.equal(t.record({ depthM: 1 }, 0), true);
  assert.equal(t.record({ depthM: 2 }, 50), false);
  assert.equal(t.record({ depthM: 3 }, 100), true);
  assert.equal(t.record({ depthM: 4 }, 200), true);
  assert.equal(t.buffer.length, 2);
  assert.equal(t.buffer[0].depthM, 3);
});

test('eventos importantes se registran aunque no haya pasado el intervalo', () => {
  const t = new Telemetry({ intervalMs: 1000, batchSize: 999 });
  assert.equal(t.event('prueba-finalizada', { aprobado: true }), true);
  assert.equal(t.buffer[0].evento, 'prueba-finalizada');
  assert.equal(t.buffer[0].aprobado, true);
});

test('un fallo de red conserva los datos pendientes para reintentar', async () => {
  const originalFetch = globalThis.fetch;
  let calls = 0;
  globalThis.fetch = async () => {
    calls++;
    if (calls === 1) throw new Error('offline');
    return { ok: true, status: 204 };
  };
  try {
    const t = new Telemetry({ intervalMs: 1, batchSize: 50 });
    t.record({ depthM: 4 }, 10);
    assert.equal(await t.flush(), false);
    assert.equal(t.pending.length, 1);
    assert.equal(await t.flush(), true);
    assert.equal(t.pending.length, 0);
    assert.equal(calls, 2);
  } finally {
    globalThis.fetch = originalFetch;
  }
});
