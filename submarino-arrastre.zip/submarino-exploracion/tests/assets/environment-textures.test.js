import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const base = new URL('../../src/modules/environment/', import.meta.url);

test('el lecho y las rocas usan texturas procedurales locales', async () => {
  const source = await readFile(new URL('Seabed.js', base), 'utf8');
  assert.match(source, /new B\.DynamicTexture/);
  assert.match(source, /mat\.diffuseTexture = texturaArena/);
  assert.match(source, /mat\.bumpTexture = texturaArena/);
  assert.match(source, /mat\.diffuseTexture = texturaRelieve/);
});

test('la superficie del agua incluye patrón de ondas generado localmente', async () => {
  const source = await readFile(new URL('OceanModule.js', base), 'utf8');
  assert.match(source, /crearTexturaAgua/);
  assert.match(source, /mat\.diffuseTexture = this\.texturaAgua/);
  assert.match(source, /mat\.emissiveTexture = this\.texturaAgua/);
  assert.doesNotMatch(source, /https?:\/\//);
});
