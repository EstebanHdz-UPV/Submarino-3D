## Tarjeta
SUB-___ · (enlace a Trello)

## Qué cambia
(2 a 3 líneas)

## Definición de Terminado
- [ ] Cumple los criterios de aceptación de la tarjeta
- [ ] Funciona sin internet con `node server.js`
- [ ] Sin frameworks, TypeScript ni bundlers
- [ ] Formatos permitidos: .glb/.gltf, PNG/JPG/WebP, SVG
- [ ] Datos configurables en JSON
- [ ] Eventos registrados con SLog / telemetría si aplica
- [ ] Pruebas físicas hechas (si es tarjeta de física) con valores antes y después
- [ ] Entrada de bitácora agregada

## Evidencia
(captura, video o salida de la prueba)
