// Punto de entrada: carga datos JSON, crea la escena 3D, el ensamble y las pantallas.
import { SLog } from './core/SLog.js';
import { loadAll } from './core/Config.js';
import { Telemetry } from './core/Telemetry.js';
import { Loop } from './core/Loop.js';
import { EventBus } from './core/EventBus.js';
import { SceneModule } from './modules/scene/SceneModule.js';
import { ModelLoader } from './modules/scene/ModelLoader.js';
import { CameraModule } from './modules/scene/CameraModule.js';
import { AssemblyView, aBabylon } from './modules/scene/AssemblyView.js';
import { OceanModule } from './modules/environment/OceanModule.js';
import { Seabed } from './modules/environment/Seabed.js';
import { Particles } from './modules/environment/Particles.js';
import { DamageFx } from './modules/environment/DamageFx.js';
import { PartsCatalog } from './modules/submarine/PartsCatalog.js';
import { Assembly } from './modules/submarine/Assembly.js';
import { PhysicsModule } from './modules/physics/PhysicsModule.js';
import { entornoDe, caladoEquilibrio } from './modules/trials/TrialRunner.js';
import { ControlsModule } from './modules/controls/ControlsModule.js';
import { Hud } from './modules/ui/Hud.js';
import { Router } from './modules/ui/Router.js';
import { h, limpiar } from './modules/ui/dom.js';
import { icono, precargar } from './modules/ui/Icons.js';
import { HomeScreen } from './modules/ui/screens/HomeScreen.js';
import { AssemblyScreen } from './modules/ui/screens/AssemblyScreen.js';
import { TrialsScreen } from './modules/ui/screens/TrialsScreen.js';
import { StressScreen } from './modules/ui/screens/StressScreen.js';
import { ResultsScreen } from './modules/ui/screens/ResultsScreen.js';
import { BooksScreen } from './modules/ui/screens/BooksScreen.js';
import { SettingsScreen, CLIMAS } from './modules/ui/screens/SettingsScreen.js';
import { TECLAS } from './modules/controls/ControlsModule.js';

const AJUSTES_BASE = { tipoAgua: 'mar', gravedad: 9.81, clima: 'tranquilo', mostrarMalla: false, mostrarDatos: true, modoSimplificado: false };
const NAV = [['inicio', 'inicio', 'Inicio'], ['ensamblaje', 'ensamblaje', 'Ensamblaje'], ['pruebas', 'pruebas', 'Pruebas'], ['resultados', 'resultados', 'Resultados'], ['libros', 'libro', 'Libros'], ['configuracion', 'configuracion', 'Configuración']];
const PASO = { ensamblaje: 1, pruebas: 2, estres: 2, resultados: 3 };

async function boot() {
  const cargando = document.getElementById('cargando');
  const datos = await loadAll();
  const major = parseInt(String(BABYLON.Engine.Version), 10);
  if (!(major >= datos.manifest.engine.minMajor)) throw new Error(`Se requiere Babylon.js ${datos.manifest.engine.minVersion} o superior (encontrada ${BABYLON.Engine.Version})`);
  SLog.info('Main', `Proyecto ${datos.manifest.name} v${datos.manifest.version}`);

  const bus = new EventBus();
  const t = (k, d) => datos.i18n[k] ?? d ?? k;
  let settings = { ...AJUSTES_BASE };
  try { Object.assign(settings, JSON.parse(localStorage.getItem('submarino.ajustes') ?? '{}')); } catch { /* sin almacenamiento */ }

  const canvas = document.getElementById('render'), hudCanvas = document.getElementById('hud');
  const sm = new SceneModule(canvas);
  const loader = new ModelLoader(sm.scene);
  const view = new AssemblyView(sm, loader);
  const cam = new CameraModule(sm);
  const ocean = new OceanModule(sm);
  const seabed = await new Seabed(sm, loader, 250).build();
  const particles = new Particles(sm); particles.seguir(view.root);
  const fx = new DamageFx(sm);
  const hud = new Hud(hudCanvas);
  const controls = new ControlsModule(bus);
  const catalog = new PartsCatalog(datos.parts, datos.materials, datos.partTypes);
  const assembly = new Assembly(catalog, datos.rules);
  const telemetry = new Telemetry(datos.manifest.telemetry);
  precargar(['alerta', 'bateria', 'velocidad', 'profundidad', 'presion', 'motor']);

  const el = { main: document.getElementById('main'), panel: document.getElementById('panel'), stage: document.getElementById('stage'), controlStatus: document.getElementById('control-status'), nav: document.getElementById('nav'),
    pasos: document.getElementById('pasos'), toasts: document.getElementById('toasts'), ayuda: document.getElementById('ayuda') };

  const app = {
    datos, bus, t, sm, loader, view, cam, ocean, seabed, particles, fx, hud, controls, catalog, assembly, telemetry, slog: SLog,
    panel: el.panel, settings, estado: { escenarioId: 'inmersion', cond: {} }, resultado: null, manual: null, modo: null, router: null,
    worldEfectivo: () => ({ ...datos.physics, gravedad: settings.gravedad, modoSimplificado: settings.modoSimplificado }),
    stats() { return assembly.stats(app.worldEfectivo(), entornoDe({ temperaturaC: 15 }, settings)); },
    go: (id) => app.router.ir(id),
    aviso(msg, tipo = 'info') { const n = h('div', { class: `toast ${tipo}` }, msg); el.toasts.append(n); setTimeout(() => n.remove(), 3800); },
    async refrescarVista() { await view.actualizar(assembly, app.stats()); },
    guardarAjustes(b) {
      settings = b ? { ...AJUSTES_BASE, ...b } : { ...AJUSTES_BASE }; app.settings = settings;
      try { localStorage.setItem('submarino.ajustes', JSON.stringify(settings)); } catch { /* ignorar */ }
      sm.scene.forceWireframe = settings.mostrarMalla;
    },
    mostrarEscena(visible, modo) {
      el.main.classList.toggle('con-escena', visible);
      if (visible) { app.modoEscena(modo ?? 'taller'); requestAnimationFrame(() => { sm.resize(); hud.resize(); }); }
    },
    modoEscena(modo) {
      app.modo = modo;
      const agua = modo === 'agua';
      ocean.superficie.setEnabled(agua); seabed.setEnabled(agua);
      if (agua) particles.iniciar(); else particles.detener();
      if (!agua) {
        sm.scene.fogDensity = 0; sm.scene.clearColor.set(0.03, 0.09, 0.16, 1); sm.ambient.intensity = 0.9; sm.sun.intensity = 0.9;
        view.ponerEn(0); if (!app.manual) cam.setModo('taller');
      }
    },
    vistaPrevia(profundidadM) {
      view.ponerEn(profundidadM); cam.setModo('orbita');
      sm.arc.target.set(0, -profundidadM, 0); cam.targetSuave = sm.arc.target.clone(); sm.arc.radius = 10; sm.arc.alpha = -Math.PI / 3; sm.arc.beta = 1.3;
    },
    async cargarEjemplo() { const r = await fetch(datos.manifest.data.exampleDesign); await app.cargarDiseno(await r.json()); },
    async cargarDiseno(json) {
      const errs = assembly.load(json);
      if (errs.length) app.aviso(errs.join(' '), 'error'); else app.aviso(t('app.cargado', 'Diseño cargado'));
      await app.refrescarVista();
    },
    async _enviar(kind, nombre, data) {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const a = h('a', { href: URL.createObjectURL(blob), download: `${kind}-${nombre}.json` }); a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      try { const r = await fetch('/api/designs', { method: 'POST', body: JSON.stringify({ kind, name: nombre, data }) }); const j = await r.json(); app.aviso(`Guardado en ${j.file}`); }
      catch (e) { SLog.warn('Main', 'No se pudo guardar en el servidor local', e.message); }
    },
    guardarDiseno() { const n = `submarino-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}`; return app._enviar('diseno', n, assembly.toJSON(n)); },
    guardarReporte(r) {
      const n = `${r.escenario.id}-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}`;
      return app._enviar('reporte', n, { escenario: r.escenario.id, condiciones: r.cond, resumen: r.resumen, dictamen: r.dictamen, eventos: r.eventos, diseno: assembly.toJSON(n), estadisticas: { masaSecaKg: r.stats.masaSecaKg, profundidadDisenoM: r.stats.profundidadDisenoM, profundidadColapsoM: r.stats.profundidadColapsoM } });
    },
    iniciarManual(cond) {
      const clima = CLIMAS.find((c) => c[0] === settings.clima)?.[2] ?? 0;
      const env = entornoDe({ ...cond, corrienteMs: clima }, settings);
      const world = app.worldEfectivo(), stats = assembly.stats(world, env);
      app.manual = { phys: new PhysicsModule(world, env, stats, { startDepthM: caladoEquilibrio(stats), fill: 0 }), stats, cond, world, env };
      controls.attach(); el.controlStatus.classList.remove('oculto'); app.modoEscena('agua'); cam.setModo('seguimiento'); cam.targetSuave = view.root.position.clone();
      telemetry.event('piloto-manual-inicio', { temperaturaC: env.temperaturaC });
      hud.resize();
    },
    detenerManual() { if (!app.manual) return; controls.detach(); app.manual = null; el.controlStatus.classList.add('oculto'); hud.limpiar(); telemetry.event('piloto-manual-fin'); telemetry.flush(); if (app.modo === 'agua') app.vistaPrevia(app.estado.cond[app.estado.escenarioId]?.profundidadM ?? 0); }
  };
  app.guardarAjustes(settings);

  bus.on('camara-siguiente', () => { if (app.manual) app.aviso(`Cámara: ${cam.siguiente()}`); });
  bus.on('reiniciar', () => { if (app.manual) { const { cond } = app.manual; app.detenerManual(); app.iniciarManual(cond); app.aviso('Exploración reiniciada'); } });
  bus.on('soltar-pesos', () => app.manual?.phys.releaseWeights());
  bus.on('ayuda', () => el.ayuda.classList.toggle('oculto'));
  limpiar(el.ayuda).append(h('strong', {}, t('ayuda.titulo', 'Controles')), ...TECLAS.map(([k, d]) => h('div', {}, h('kbd', {}, k), ' ', d)));

  // --- navegación y pasos ---
  for (const [id, ic, nombre] of NAV) el.nav.append(h('button', { class: 'nav-item', dataset: { ruta: id }, onclick: () => app.go(id) }, icono(ic, 22), h('span', {}, t(`nav.${id}`, nombre))));
  [[1, 'Ensamblaje'], [2, 'Pruebas'], [3, 'Resultados']].forEach(([n, nombre]) => el.pasos.append(h('div', { class: 'paso', dataset: { n } }, h('span', { class: 'paso-num' }, n), h('span', {}, t(`paso.${n}`, nombre)))));

  app.router = new Router({
    inicio: HomeScreen(app), ensamblaje: AssemblyScreen(app), pruebas: TrialsScreen(app), estres: StressScreen(app), resultados: ResultsScreen(app), libros: BooksScreen(app), configuracion: SettingsScreen(app)
  }, {
    alCambiar(id) {
      el.nav.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('activo', b.dataset.ruta === id || (id === 'estres' && b.dataset.ruta === 'pruebas')));
      const n = PASO[id] ?? 0;
      el.pasos.classList.toggle('oculto', n === 0);
      el.pasos.querySelectorAll('.paso').forEach((p) => { const k = Number(p.dataset.n); p.classList.toggle('activo', k === n); p.classList.toggle('hecho', k < n); });
    }
  });

  // --- bucle de simulación (paso fijo) ---
  const loop = new Loop({
    fixedStep: datos.physics.pasoFijoS, maxDt: datos.physics.dtMaxS,
    step(dt) {
      const m = app.manual; if (!m) return;
      const snap = m.phys.step(dt, controls.read(dt));
      telemetry.record({ t: +snap.t.toFixed(2), depthM: +snap.depthM.toFixed(2), speedMs: +snap.speedMs.toFixed(3), headingDeg: +snap.headingDeg.toFixed(1), pitchDeg: +snap.pitchDeg.toFixed(2), rollDeg: +snap.rollDeg.toFixed(2),
        thrustN: +snap.thrustN.toFixed(0), ballastFill: +snap.ballastFill.toFixed(3), pressureAtm: +snap.pressureAtm.toFixed(2), soc: +snap.soc.toFixed(4), powerW: +snap.powerW.toFixed(0) });
      for (const ev of m.phys.events.splice(0)) telemetry.event(ev.tipo, ev);
    },
    update(dtReal) {
      const m = app.manual;
      if (m) {
        view.aplicarPose(m.phys.pos, m.phys.R);
        const snap = m.phys.snapshot(), cs = controls.estado();
        el.controlStatus.innerHTML = `<div class="cs-title"><span>PILOTO MANUAL · WASD</span><span>${snap.powered ? 'ENERGÍA OK' : 'SIN ENERGÍA'}</span></div><div class="cs-grid"><div>Velocidad<br><span class="cs-value">${snap.speedMs.toFixed(2)} m/s</span></div><div>Profundidad<br><span class="cs-value">${snap.depthM.toFixed(1)} m</span></div><div>Empuje<br><span class="cs-value">${Math.round(snap.throttle * 100)}%</span></div><div>Rumbo<br><span class="cs-value">${Math.round(snap.headingDeg)}°</span></div><div>Batería<br><span class="cs-value">${Math.round(snap.soc * 100)}%</span></div><div>Timón<br><span class="cs-value">${cs.rudder < 0 ? 'IZQ.' : cs.rudder > 0 ? 'DER.' : 'CENTRO'}</span></div></div><div class="cs-keys">Teclas activas: ${cs.teclas.length ? cs.teclas.map(k => `<kbd>${k}</kbd>`).join(' ') : 'ninguna'} · W acelera, S reduce empuje</div>`;
        cam.update(dtReal, view.root.position, view.adelante, view.arriba, view.posCabina());
        ocean.update(-sm.scene.activeCamera.globalPosition.y);
        hud.dibujar(m.phys.snapshot(), m.stats, { mostrarDatos: settings.mostrarDatos, sonar: { posB: view.root.position, headingRad: Math.atan2(view.adelante.x, view.adelante.z), fondoY: view.root.position.y, alturaFondo: (x, z) => seabed.heightAt(x, z) } });
      } else if (app.modo === 'agua') ocean.update(-sm.scene.activeCamera.globalPosition.y);
    }
  });
  sm.run((dt) => loop.tick(dt));

  new ResizeObserver(() => { sm.resize(); hud.resize(); }).observe(el.stage);
  addEventListener('resize', () => { sm.resize(); hud.resize(); });
  addEventListener('beforeunload', () => telemetry.flush());
  setInterval(() => telemetry.flush(), 5000);

  globalThis.__submarino = app; // para depuración desde la consola
  await app.router.resolver();
  cargando.classList.add('oculto');
  SLog.info('Main', 'Aplicación lista');
}

boot().catch((e) => {
  SLog.error('Main', 'Fallo de arranque', e.message);
  const c = document.getElementById('cargando');
  if (c) { c.classList.remove('oculto'); c.classList.add('error'); c.textContent = `No se pudo iniciar: ${e.message}`; }
});
