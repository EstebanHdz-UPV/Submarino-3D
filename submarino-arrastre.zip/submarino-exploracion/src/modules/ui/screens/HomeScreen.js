import { h, limpiar } from '../dom.js';
import { icono } from '../Icons.js';

export function HomeScreen(app) {
  const { t } = app;
  return {
    async mount() {
      app.mostrarEscena(false);
      limpiar(app.panel).append(
        h('section', { class: 'hero' },
          h('div', { class: 'hero-txt' },
            h('p', { class: 'sup' }, t('inicio.sup', 'Bienvenido al')),
            h('h1', {}, t('inicio.titulo', 'Simulador de Submarinos 3D')),
            h('p', { class: 'lead' }, t('inicio.texto', 'Arma, prueba y analiza el rendimiento de tu submarino en un entorno realista y seguro.')),
            h('ol', { class: 'pasos-inicio' },
              h('li', {}, t('inicio.paso1', 'Consulta los dos libros: piezas y materiales.')),
              h('li', {}, t('inicio.paso2', 'Arma el submarino pieza por pieza (aunque no esté completo).')),
              h('li', {}, t('inicio.paso3', 'Elige un escenario y pruébalo; revisa el dictamen.'))),
            h('div', { class: 'acciones' },
              h('button', { class: 'btn primario grande', onclick: () => app.go('ensamblaje') }, t('inicio.comenzar', 'Comenzar')),
              h('button', { class: 'btn secundario grande', onclick: async () => { await app.cargarEjemplo(); app.go('ensamblaje'); } }, t('inicio.ejemplo', 'Cargar submarino de ejemplo')),
              h('button', { class: 'btn secundario grande', onclick: () => app.go('libros') }, t('inicio.libros', 'Ver los libros')))),
          h('div', { class: 'hero-img' }, icono('submarino', 220, 'hero-icono'))));
    },
    unmount() {}
  };
}
