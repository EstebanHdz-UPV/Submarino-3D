// Carga modelos .glb/.gltf. Si falla, usa una pieza procedural (RNF: alternativa ante recursos faltantes).
import { SLog } from '../../core/SLog.js';

const COLORES = {
  casco: [0.55, 0.62, 0.7], propulsion: [0.25, 0.28, 0.32], lastre: [0.85, 0.55, 0.15], cabina: [0.3, 0.65, 0.95], aletas: [0.2, 0.3, 0.45],
  torre: [0.45, 0.5, 0.55], bateria: [0.2, 0.7, 0.35], lastreFijo: [0.3, 0.3, 0.32], flotabilidad: [0.95, 0.8, 0.25], focos: [1, 0.95, 0.6], sonar: [0.7, 0.3, 0.3]
};

export class ModelLoader {
  constructor(scene, base = 'assets/models/') { this.scene = scene; this.base = base; this.fallos = new Set(); }

  /**
   * Devuelve un TransformNode escalado a `dims` (largo en z, ancho en x, alto en y) y centrado en el origen.
   * @returns {Promise<{node: BABYLON.TransformNode, origen: 'glb'|'procedural'}>}
   */
  async cargarPieza(pieza, dims, nombre) {
    const B = BABYLON;
    const contenedor = new B.TransformNode(`pieza-${nombre}`, this.scene);
    let meshes = [], origen = 'glb';
    try {
      const url = this.base + pieza.archivo;
      const res = B.ImportMeshAsync ? await B.ImportMeshAsync(url, this.scene) : await B.SceneLoader.ImportMeshAsync('', this.base, pieza.archivo, this.scene);
      meshes = res.meshes;
      const raiz = meshes[0];
      raiz.parent = contenedor; // __root__
      this._ajustar(contenedor, meshes, dims);
    } catch (e) {
      origen = 'procedural';
      if (!this.fallos.has(pieza.archivo)) { this.fallos.add(pieza.archivo); SLog.warn('ModelLoader', `No se pudo cargar ${pieza.archivo}; se usa una pieza procedural`, e?.message ?? String(e)); }
      meshes = this._procedural(pieza, dims, contenedor);
    }
    return { node: contenedor, meshes, origen };
  }

  _ajustar(contenedor, meshes, dims) {
    const B = BABYLON;
    contenedor.computeWorldMatrix(true);
    let min = new B.Vector3(Infinity, Infinity, Infinity), max = new B.Vector3(-Infinity, -Infinity, -Infinity);
    for (const m of meshes) {
      if (!m.getBoundingInfo || !m.getTotalVertices || m.getTotalVertices() === 0) continue;
      m.computeWorldMatrix(true);
      const bb = m.getBoundingInfo().boundingBox;
      min = B.Vector3.Minimize(min, bb.minimumWorld); max = B.Vector3.Maximize(max, bb.maximumWorld);
    }
    const size = max.subtract(min);
    if (!isFinite(size.x) || size.x <= 0 || size.y <= 0 || size.z <= 0) return;
    const k = new B.Vector3(dims.ancho / size.x, dims.alto / size.y, dims.largo / size.z);
    const centro = min.add(max).scale(0.5);
    contenedor.scaling = k;
    contenedor.position = new B.Vector3(-centro.x * k.x, -centro.y * k.y, -centro.z * k.z);
  }

  _procedural(pieza, dims, padre) {
    const B = BABYLON, s = this.scene, c = COLORES[pieza.tipo] ?? [0.6, 0.6, 0.6];
    let m;
    const esf = pieza.forma === 'esfera' || pieza.tipo === 'cabina' || pieza.tipo === 'focos';
    if (esf) m = B.MeshBuilder.CreateSphere('p', { diameter: 1, segments: 16 }, s);
    else if (['casco', 'propulsion', 'lastre', 'sonar'].includes(pieza.tipo)) {
      m = B.MeshBuilder.CreateCylinder('p', { height: 1, diameter: 1, tessellation: 24 }, s);
      m.rotation.x = Math.PI / 2; m.bakeCurrentTransformIntoVertices();
    } else m = B.MeshBuilder.CreateBox('p', { size: 1 }, s);
    m.scaling = new B.Vector3(dims.ancho, dims.alto, dims.largo);
    m.parent = padre;
    const mat = new B.StandardMaterial('mat-p', s);
    mat.diffuseColor = new B.Color3(...c); mat.specularColor = new B.Color3(0.2, 0.2, 0.2);
    if (pieza.tipo === 'cabina') mat.alpha = 0.6;
    m.material = mat;
    return [m];
  }
}
