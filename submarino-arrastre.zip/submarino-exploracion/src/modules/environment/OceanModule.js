// Agua: color, niebla y atenuación de luz con la profundidad; superficie del mar.
const lerp = (a, b, t) => a + (b - a) * t;

/** Textura de ondas generada en canvas para que el entorno funcione sin recursos externos. */
function crearTexturaAgua(B, scene) {
  const tex = new B.DynamicTexture('tex-ondas-superficie', { width: 512, height: 512 }, scene, false, B.Texture.TRILINEAR_SAMPLINGMODE);
  const ctx = tex.getContext();
  ctx.fillStyle = '#164f65'; ctx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 180; i++) {
    const y = (i * 17) % 512;
    ctx.beginPath(); ctx.moveTo(0, y);
    for (let x = 0; x <= 512; x += 8) ctx.lineTo(x, y + Math.sin((x + i * 13) * 0.025) * (2 + (i % 5)) + Math.sin(x * 0.07 + i) * 1.2);
    ctx.strokeStyle = i % 3 === 0 ? 'rgba(150,222,230,0.16)' : 'rgba(3,25,42,0.11)';
    ctx.lineWidth = i % 4 === 0 ? 2 : 1; ctx.stroke();
  }
  // Destellos irregulares, como la luz que atraviesa las ondas.
  for (let i = 0; i < 420; i++) {
    const x = (i * 73) % 512, y = (i * 137) % 512;
    ctx.fillStyle = `rgba(177,231,235,${0.025 + (i % 5) * 0.012})`;
    ctx.beginPath(); ctx.ellipse(x, y, 2 + (i % 6), 0.7 + (i % 2), (i % 7) * 0.2, 0, Math.PI * 2); ctx.fill();
  }
  tex.update(false); tex.wrapU = B.Texture.WRAP_ADDRESSMODE; tex.wrapV = B.Texture.WRAP_ADDRESSMODE;
  tex.anisotropicFilteringLevel = 4;
  return tex;
}

export class OceanModule {
  constructor(sm) {
    const B = BABYLON;
    this.sm = sm;
    this.superficie = B.MeshBuilder.CreateGround('superficie', { width: 3000, height: 3000, subdivisions: 1 }, sm.scene);
    const mat = new B.StandardMaterial('mat-superficie', sm.scene);
    this.texturaAgua = crearTexturaAgua(B, sm.scene);
    mat.diffuseTexture = this.texturaAgua; mat.emissiveTexture = this.texturaAgua;
    mat.diffuseTexture.uScale = mat.diffuseTexture.vScale = 5;
    mat.emissiveTexture.uScale = mat.emissiveTexture.vScale = 5;
    mat.emissiveColor = new B.Color3(0.18, 0.55, 0.67); mat.disableLighting = true; mat.alpha = 0.34; mat.backFaceCulling = false; mat.specularColor = new B.Color3(0.5, 0.8, 0.9); mat.specularPower = 48;
    this.superficie.material = mat; this.superficie.isPickable = false;
    this.shallow = [0.08, 0.42, 0.55]; this.deep = [0.006, 0.02, 0.05];
  }
  /** Intensidad relativa de la luz del sol a una profundidad (m): I = exp(-k·z). */
  static luz(depthM) { return Math.exp(-Math.max(0, depthM) / 35); }
  /** Ajusta color, niebla y luces según la profundidad de la cámara (m, positiva hacia abajo). */
  update(camDepthM) {
    const { scene } = this.sm;
    if (camDepthM < 0) { // sobre el agua
      scene.clearColor.set(0.55, 0.75, 0.9, 1); scene.fogColor.set(...this.shallow); scene.fogDensity = 0.008; // la niebla acuática sigue activa
      this.sm.ambient.intensity = 1; this.sm.sun.intensity = 1.1; return;
    }
    const t = 1 - Math.exp(-camDepthM / 70);
    const c = this.shallow.map((v, i) => lerp(v, this.deep[i], t));
    scene.clearColor.set(c[0], c[1], c[2], 1); scene.fogColor.set(c[0], c[1], c[2]);
    scene.fogDensity = lerp(0.012, 0.03, t);
    const luz = OceanModule.luz(camDepthM);
    this.sm.ambient.intensity = 0.12 + 0.75 * luz;
    this.sm.sun.intensity = 1.0 * luz;
  }
}
