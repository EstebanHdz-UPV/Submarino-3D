// Lecho marino: intenta cargar lecho-marino.glb; si es un marcador plano usa un terreno procedural con relieve.
import { SLog } from '../../core/SLog.js';

/** Genera texturas procedurales locales; no descarga imágenes ni necesita conexión. */
function crearTexturaProcedural(B, scene, nombre, tipo, size = 512) {
  const tex = new B.DynamicTexture(`tex-${nombre}`, { width: size, height: size }, scene, false, B.Texture.TRILINEAR_SAMPLINGMODE);
  const ctx = tex.getContext();
  let seed = tipo === 'arena' ? 9341 : 2879;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
  if (tipo === 'arena') {
    ctx.fillStyle = '#786b52'; ctx.fillRect(0, 0, size, size);
    // Variación de color de sedimento, partículas finas y pequeñas vetas de arena.
    for (let i = 0; i < 18000; i++) {
      const x = rnd() * size, y = rnd() * size, r = 0.35 + rnd() * 2.1;
      const v = Math.floor(90 + rnd() * 90);
      ctx.fillStyle = rnd() > 0.53 ? `rgba(${v + 30},${v + 20},${v - 2},${0.08 + rnd() * 0.24})` : `rgba(28,25,19,${0.04 + rnd() * 0.16})`;
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    }
    for (let i = 0; i < 55; i++) {
      const x = rnd() * size, y = rnd() * size;
      ctx.strokeStyle = `rgba(198,177,135,${0.06 + rnd() * 0.12})`; ctx.lineWidth = 1 + rnd() * 3;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + rnd() * 28, y + rnd() * 10, x + 12 + rnd() * 35, y + 4 + rnd() * 12); ctx.stroke();
    }
  } else if (tipo === 'roca') {
    ctx.fillStyle = '#343b3d'; ctx.fillRect(0, 0, size, size);
    for (let i = 0; i < 9500; i++) {
      const x = rnd() * size, y = rnd() * size, r = 1 + rnd() * 8, v = Math.floor(55 + rnd() * 95);
      ctx.fillStyle = `rgba(${v - 4},${v},${v + 3},${0.12 + rnd() * 0.3})`;
      ctx.beginPath(); ctx.moveTo(x - r, y - r * 0.4); ctx.lineTo(x + r * 0.5, y - r); ctx.lineTo(x + r, y + r * 0.4); ctx.lineTo(x - r * 0.3, y + r); ctx.closePath(); ctx.fill();
    }
  }
  tex.update(false);
  tex.wrapU = B.Texture.WRAP_ADDRESSMODE; tex.wrapV = B.Texture.WRAP_ADDRESSMODE;
  tex.anisotropicFilteringLevel = 4;
  return tex;
}

export class Seabed {
  constructor(sm, loader, fondoM = 250) {
    this.sm = sm; this.loader = loader; this.fondoM = fondoM; this.node = null; this.size = 800; this.rocas = [];
  }
  /** Altura (y de Babylon) del fondo en (x, z). */
  heightAt(x, z) {
    const r = Math.sin(x * 0.045) * Math.cos(z * 0.037) * 3 + Math.sin(x * 0.12 + z * 0.09) * 1.2 + Math.sin(z * 0.2) * 0.4;
    return -this.fondoM + r;
  }
  async build() {
    const B = BABYLON, scene = this.sm.scene;
    let usarGlb = false;
    try {
      const { node, meshes, origen } = await this.loader.cargarPieza({ archivo: 'lecho-marino.glb', tipo: 'lecho' }, { ancho: this.size, alto: 0.01, largo: this.size }, 'lecho');
      if (origen === 'glb') {
        const alto = Math.max(...meshes.filter((m) => m.getBoundingInfo).map((m) => m.getBoundingInfo().boundingBox.extendSizeWorld.y * 2));
        // (el marcador es plano: tras el ajuste mide 0,01 m; un modelo real tendrá relieve)
        if (alto > 0.5) { usarGlb = true; node.position.y = -this.fondoM; this.node = node; }
        else node.dispose();
      } else node.dispose();
    } catch (e) { SLog.warn('Seabed', 'No se pudo cargar lecho-marino.glb', e?.message); }
    const texturaArena = crearTexturaProcedural(B, scene, 'arena-lecho', 'arena');
    const texturaRelieve = crearTexturaProcedural(B, scene, 'relieve-lecho', 'roca');
    if (!usarGlb) {
      const g = B.MeshBuilder.CreateGround('lecho', { width: this.size, height: this.size, subdivisions: 100, updatable: true }, scene);
      const pos = g.getVerticesData(B.VertexBuffer.PositionKind);
      for (let i = 0; i < pos.length; i += 3) pos[i + 1] = this.heightAt(pos[i], pos[i + 2]);
      g.updateVerticesData(B.VertexBuffer.PositionKind, pos);
      const nor = []; B.VertexData.ComputeNormals(pos, g.getIndices(), nor); g.updateVerticesData(B.VertexBuffer.NormalKind, nor);
      const mat = new B.StandardMaterial('mat-lecho', scene);
      mat.diffuseTexture = texturaArena; mat.bumpTexture = texturaArena;
      mat.diffuseTexture.uScale = mat.diffuseTexture.vScale = 18;
      mat.bumpTexture.uScale = mat.bumpTexture.vScale = 18; mat.bumpTexture.level = 0.22;
      mat.diffuseColor = new B.Color3(0.9, 0.83, 0.68); mat.specularColor = new B.Color3(0.08, 0.075, 0.06);
      g.material = mat; this.node = g;
    } else {
      // Si se usa un lecho GLB real, conserva su geometría y le aplica el sedimento local.
      for (const mesh of this.node.getChildMeshes?.() ?? []) {
        if (!mesh.material || mesh.material.name?.includes('mat-lecho')) continue;
        const mat = new B.StandardMaterial(`mat-textura-${mesh.name}`, scene);
        mat.diffuseTexture = texturaArena; mat.bumpTexture = texturaArena;
        mat.diffuseTexture.uScale = mat.diffuseTexture.vScale = 8; mat.bumpTexture.uScale = mat.bumpTexture.vScale = 8; mat.bumpTexture.level = 0.18;
        mat.diffuseColor = new B.Color3(0.86, 0.8, 0.68); mesh.material = mat;
      }
    }
    this.texturas = { arena: texturaArena, roca: texturaRelieve };
    this._rocas(texturaRelieve);
    SLog.info('Seabed', usarGlb ? 'Lecho cargado desde .glb' : 'Lecho procedural', { fondoM: this.fondoM });
    return this;
  }
  setEnabled(b) { this.node?.setEnabled(b); this.rocas.forEach((r) => r.setEnabled(b)); }
  _rocas(texturaRelieve) {
    const B = BABYLON, scene = this.sm.scene;
    const mat = new B.StandardMaterial('mat-roca', scene); mat.diffuseTexture = texturaRelieve; mat.bumpTexture = texturaRelieve;
    mat.diffuseTexture.uScale = mat.diffuseTexture.vScale = 1.5; mat.bumpTexture.uScale = mat.bumpTexture.vScale = 1.5; mat.bumpTexture.level = 0.38;
    mat.diffuseColor = new B.Color3(0.78, 0.82, 0.82); mat.specularColor = new B.Color3(0.04, 0.045, 0.05);
    let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 40; i++) {
      const x = (rnd() - 0.5) * 300, z = (rnd() - 0.5) * 300, s = 1 + rnd() * 3.5;
      const m = B.MeshBuilder.CreateSphere(`roca-${i}`, { diameter: s, segments: 6 }, scene);
      m.position.set(x, this.heightAt(x, z) + s * 0.25, z); m.scaling.y = 0.6; m.material = mat; m.freezeWorldMatrix(); this.rocas.push(m);
    }
  }
}
