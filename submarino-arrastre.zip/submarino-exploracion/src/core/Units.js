// Conversiones de unidades: única definición para todo el proyecto.
export const KN = 0.514444; // 1 nudo en m/s
