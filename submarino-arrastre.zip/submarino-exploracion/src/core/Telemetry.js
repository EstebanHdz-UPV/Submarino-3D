import { SLog } from './SLog.js';

/**
 * Telemetría local: muestreo limitado, buffer circular y envío por lotes.
 * Si el servidor falla, conserva el lote para intentar enviarlo en el siguiente flush.
 */
export class Telemetry {
  constructor({ endpoint = '/api/telemetry', intervalMs = 500, batchSize = 20, maxBuffer = 1200 } = {}) {
    this.endpoint = endpoint;
    this.intervalMs = Math.max(1, Number(intervalMs) || 500);
    this.batchSize = Math.max(1, Math.floor(Number(batchSize) || 20));
    this.maxBuffer = Math.max(1, Math.floor(Number(maxBuffer) || 1200));
    this.last = -Infinity;
    this.buffer = [];
    this.pending = [];
    this.inFlight = false;
    this.serverOk = true;
  }

  /** Registra una muestra si pasó el intervalo. */
  record(sample, nowMs = performance.now()) {
    if (!sample || typeof sample !== 'object' || Array.isArray(sample)) return false;
    if (!Number.isFinite(nowMs) || nowMs - this.last < this.intervalMs) return false;
    this.last = nowMs;
    this.#push({ ts: new Date().toISOString(), ...sample });
    if (this.pending.length >= this.batchSize) void this.flush();
    return true;
  }

  /** Registra un evento importante, sin aplicar el límite de frecuencia de las muestras. */
  event(tipo, detalle = {}) {
    if (!tipo || typeof tipo !== 'string') return false;
    const s = { ts: new Date().toISOString(), evento: tipo, ...detalle };
    this.#push(s);
    SLog.info('Telemetry', `Evento ${tipo}`, detalle);
    if (this.pending.length >= this.batchSize) void this.flush();
    return true;
  }

  #push(sample) {
    this.buffer.push(sample);
    if (this.buffer.length > this.maxBuffer) this.buffer.splice(0, this.buffer.length - this.maxBuffer);
    this.pending.push(sample);
  }

  /** Envía un lote. Los fallos no descartan los datos y se pueden reintentar. */
  async flush() {
    if (!this.pending.length || this.inFlight) return false;
    const batch = this.pending.splice(0, this.pending.length);
    this.inFlight = true;
    try {
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-ndjson' },
        body: batch.map((s) => JSON.stringify(s)).join('\n'),
        keepalive: true
      });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      this.serverOk = true;
      return true;
    } catch (e) {
      // Mantiene el orden y conserva lo que se haya acumulado durante la petición.
      this.pending = [...batch, ...this.pending];
      this.serverOk = false;
      SLog.warn('Telemetry', 'No se pudo enviar la telemetría; los datos quedan pendientes para reintento', e.message);
      return false;
    } finally {
      this.inFlight = false;
    }
  }

  /** Descarga el buffer local como JSONL. */
  exportJSONL() {
    const blob = new Blob([this.buffer.map((s) => JSON.stringify(s)).join('\n')], { type: 'application/x-ndjson' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `telemetria-${Date.now()}.jsonl`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
}
