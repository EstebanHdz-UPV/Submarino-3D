// Servidor local. ÚNICO uso de Node en el proyecto: servir archivos y guardar telemetría/diseños.
// Solo módulos nativos. Escucha únicamente en 127.0.0.1.
import http from 'node:http';
import { readFile, appendFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(fileURLToPath(new URL('.', import.meta.url)));
const PORT = Number(process.env.PORT) || 3000;
const HOST = '127.0.0.1';
const MAX_BODY = 1024 * 1024; // 1 MB

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.md': 'text/markdown; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json', '.bin': 'application/octet-stream', '.wasm': 'application/wasm'
};

const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; " +
  "connect-src 'self' data: blob:; worker-src 'self' blob:; object-src 'none'; base-uri 'self'";

async function readBody(req) {
  let size = 0; const chunks = [];
  for await (const c of req) {
    size += c.length;
    if (size > MAX_BODY) throw new Error('Cuerpo demasiado grande');
    chunks.push(c);
  }
  return Buffer.concat(chunks).toString('utf8');
}

const safeName = (s) => String(s ?? 'sin-nombre').toLowerCase().replace(/[^a-z0-9-_]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'sin-nombre';
const send = (res, code, body, headers = {}) => {
  res.writeHead(code, { 'Content-Security-Policy': CSP, 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(body);
};

const SESSION = new Date().toISOString().replace(/[:.]/g, '-');

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${HOST}`);

    // --- API (únicas rutas que escriben, y solo dentro de data/) ---
    if (req.method === 'POST' && url.pathname === '/api/telemetry') {
      const body = (await readBody(req)).trim();
      if (!body) return send(res, 400, 'Telemetría vacía');
      const lines = body.split(/\r?\n/);
      if (lines.length > 500) return send(res, 413, 'Demasiadas muestras en un lote');
      try {
        for (const line of lines) {
          const sample = JSON.parse(line);
          if (!sample || typeof sample !== 'object' || Array.isArray(sample) || typeof sample.ts !== 'string' || !Number.isFinite(Date.parse(sample.ts))) {
            return send(res, 400, 'Muestra de telemetría inválida');
          }
        }
      } catch { return send(res, 400, 'JSONL de telemetría inválido'); }
      await mkdir(join(ROOT, 'data/telemetry'), { recursive: true });
      await appendFile(join(ROOT, 'data/telemetry', `session-${SESSION}.jsonl`), lines.join('\n') + '\n');
      return send(res, 204, '');
    }
    if (req.method === 'POST' && url.pathname === '/api/designs') {
      const payload = JSON.parse(await readBody(req)); // { kind, name, data }
      const kind = payload.kind === 'reporte' ? 'reporte' : 'diseno';
      const file = `${kind}-${safeName(payload.name)}.json`;
      await mkdir(join(ROOT, 'data/designs'), { recursive: true });
      await writeFile(join(ROOT, 'data/designs', file), JSON.stringify(payload.data, null, 2));
      return send(res, 200, JSON.stringify({ ok: true, file: `data/designs/${file}` }), { 'Content-Type': MIME['.json'] });
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método no permitido');

    // --- Archivos estáticos con protección contra path traversal ---
    const rel = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
    const full = resolve(join(ROOT, rel));
    if (full !== ROOT && !full.startsWith(ROOT + sep)) return send(res, 403, 'Prohibido');
    if (rel.split('/').some((p) => p.startsWith('.'))) return send(res, 403, 'Prohibido');
    // Los registros de telemetría son datos de ejecución, no recursos públicos de la interfaz.
    if (rel.replaceAll('\\', '/').startsWith('/data/telemetry/')) return send(res, 403, 'Prohibido');
    const info = await stat(full);
    if (!info.isFile()) return send(res, 404, 'No encontrado');
    const data = await readFile(full);
    send(res, 200, req.method === 'HEAD' ? '' : data, {
      'Content-Type': MIME[extname(full).toLowerCase()] ?? 'application/octet-stream',
      'Cache-Control': 'no-cache'
    });
  } catch (e) {
    const notFound = e && e.code === 'ENOENT';
    send(res, notFound ? 404 : 400, notFound ? 'No encontrado' : 'Solicitud inválida');
  }
}).listen(PORT, HOST, () => console.log(`Submarino de exploración en http://localhost:${PORT} (solo local)`));
