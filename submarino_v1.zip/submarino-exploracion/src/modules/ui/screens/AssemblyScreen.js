import { h, limpiar, fmt } from '../dom.js';
import { icono } from '../Icons.js';
import { consecuencias } from '../../submarine/MissingParts.js';

const resumen = (p) => {
  switch (p.tipo) {
    case 'casco': return `${p.forma} · radio ${p.radioM} m · pared ${(p.espesorM * 1000).toFixed(0)} mm`;
    case 'propulsion': return `${p.empujeMaxN} N · ${(p.potenciaNominalW / 1000).toFixed(1)} kW · ${p.masaKg} kg`;
    case 'lastre': return `${p.volumenM3} m³ · ${p.masaKg} kg`;
    case 'cabina': case 'torre': return `hasta ${p.profundidadDisenoM} m · ${p.masaKg} kg`;
    case 'aletas': return `${p.areaAletasM2} m² · ${p.masaKg} kg`;
    case 'bateria': return `${p.capacidadWh / 1000} kWh · ${p.masaKg} kg`;
    case 'lastreFijo': return `${p.masaKg} kg`;
    case 'flotabilidad': return `${p.volumenM3} m³ · hasta ${p.profundidadDisenoM} m`;
    case 'focos': return `${p.consumoW} W · ${p.alcanceLuzM} m`;
    case 'sonar': return `${p.alcanceM} m · ${p.consumoW} W`;
    default: return '';
  }
};

export function AssemblyScreen(app) {
  const { t } = app;
  let slotSel = 'casco';
  let cont;

  async function cambiar(fn) { const r = fn(); if (r && r.ok === false) app.aviso(r.error, 'error'); await app.refrescarVista(); pintar(); }

  function listaSlots() {
    return h('div', { class: 'lista-piezas' }, app.assembly.slots.map((s) => {
      const puesto = !!app.assembly.get(s.id);
      return h('button', { class: 'slot-item' + (slotSel === s.id ? ' activo' : ''), onclick: () => { slotSel = s.id; pintar(); } },
        icono('pieza', 22),
        h('span', { class: 'slot-nombre' }, s.nombre, s.obligatorio ? h('em', { class: 'obl' }, ' *') : null),
        h('span', { class: 'slot-estado ' + (puesto ? 'ok' : 'falta') }, puesto ? '✓' : '—'));
    }));
  }

  function detalle() {
    const slot = app.assembly.slot(slotSel); if (!slot) return h('div');
    const actual = app.assembly.piezas[slot.id];
    const variantes = app.catalog.byTipo(slot.tipo);
    const hijos = [h('h4', {}, slot.nombre), h('p', { class: 'tenue pequeno' }, slot.faltante)];
    hijos.push(h('div', { class: 'variantes' }, variantes.map((p) => h('button', {
      class: 'variante' + (actual?.partId === p.id ? ' activo' : ''),
      onclick: () => cambiar(() => {
        const mat = slot.tipo === 'casco' && actual && p.materialesPermitidos.includes(actual.materialId) ? actual.materialId : undefined;
        return app.assembly.place(slot.id, p.id, mat);
      })
    }, h('strong', {}, p.nombre), h('span', { class: 'tenue pequeno' }, resumen(p)), h('span', { class: 'tenue pequeno' }, p.descripcion)))));
    if (slot.tipo === 'casco' && actual) {
      const part = app.catalog.part(actual.partId);
      hijos.push(h('label', { class: 'campo' }, t('ens.material', 'Material del casco'),
        h('select', { onchange: (e) => cambiar(() => app.assembly.place('casco', actual.partId, e.target.value)) },
          part.materialesPermitidos.map((id) => { const m = app.catalog.material(id); return h('option', { value: id, selected: id === actual.materialId }, `${m.nombre} · ${m.densidadKgM3} kg/m³ · ${m.limiteElasticoMPa} MPa`); }))));
      const m = app.catalog.material(actual.materialId);
      hijos.push(h('p', { class: 'tenue pequeno' }, m.uso));
    }
    if (actual) hijos.push(h('button', { class: 'btn peligro', onclick: () => cambiar(() => app.assembly.remove(slot.id)) }, t('ens.quitar', 'Quitar pieza')));
    return h('div', { class: 'detalle' }, hijos);
  }

  function estadisticas() {
    const st = app.stats();
    const fila = (k, v, mal) => h('div', { class: 'fila-stat' + (mal ? ' mal' : '') }, h('span', {}, k), h('strong', {}, v));
    if (!st.casco) return h('div', { class: 'tarjeta' }, h('h4', {}, t('ens.stats', 'Estadísticas del diseño')), h('p', { class: 'tenue' }, t('ens.sincasco', 'Coloca un casco para ver las estadísticas.')));
    const neto = st.flotabilidadNetaKg;
    return h('div', { class: 'tarjeta' }, h('h4', {}, t('ens.stats', 'Estadísticas del diseño')),
      fila(t('ens.masa', 'Masa total (en seco)'), `${fmt(st.masaSecaKg, 0)} kg`),
      fila(t('ens.volumen', 'Volumen desplazado'), `${fmt(st.volumenEnvolventeM3, 2)} m³`),
      fila(t('ens.flot', 'Flotabilidad neta (lastre vacío)'), `${fmt(neto, 0)} kg`, neto < 0),
      fila(t('ens.neutro', 'Llenado de lastre neutro'), st.llenadoNeutro === null ? '—' : `${fmt(st.llenadoNeutro * 100, 0)} %`, st.llenadoNeutro !== null && (st.llenadoNeutro < 0 || st.llenadoNeutro > 1)),
      fila(t('ens.diseno', 'Profundidad de diseño'), `${fmt(st.profundidadDisenoM, 0)} m`),
      fila(t('ens.colapso', 'Profundidad de colapso'), `${fmt(st.profundidadColapsoM, 0)} m`),
      fila(t('ens.limitante', 'Pieza limitante'), st.limitante),
      fila(t('ens.bg', 'Estabilidad (BG)'), `${fmt(st.bgM, 2)} m`, st.bgM <= 0),
      fila(t('ens.trim', 'Trimado estimado'), st.trimadoDeg === null ? '—' : `${fmt(st.trimadoDeg, 1)}°`),
      fila(t('ens.autonomia', 'Autonomía a 1,5 m/s'), st.autonomiaCrucero ? `${fmt(st.autonomiaCrucero.horas, 1)} h` : '—'),
      fila(t('ens.costo', 'Costo estimado'), `$${fmt(st.costoUsd, 0)} USD`),
      st.advertencias.length ? h('ul', { class: 'advertencias' }, st.advertencias.map((a) => h('li', {}, a))) : null);
  }

  function pintar() {
    limpiar(cont);
    const st = app.stats();
    const cons = consecuencias(st).filter((c) => c.severidad !== 'aviso' || false);
    cont.append(
      h('h2', {}, t('ens.titulo', 'Armar submarino')),
      h('p', { class: 'tenue' }, t('ens.sub', 'Selecciona un punto de montaje y elige una pieza. * = obligatoria.')),
      listaSlots(), detalle(), estadisticas(),
      cons.length ? h('div', { class: 'tarjeta aviso-caja' }, h('h4', {}, icono('alerta', 18), ' ', t('ens.faltan', 'Faltan piezas (se puede probar igual)')), h('ul', {}, cons.map((c) => h('li', {}, c.mensaje)))) : null,
      h('div', { class: 'acciones' },
        h('button', { class: 'btn secundario', onclick: () => cambiar(() => { app.assembly.clear(); }) }, t('ens.limpiar', 'Empezar de cero')),
        h('button', { class: 'btn secundario', onclick: async () => { await app.cargarEjemplo(); pintar(); } }, t('ens.ejemplo', 'Cargar ejemplo')),
        h('button', { class: 'btn secundario', onclick: () => app.guardarDiseno() }, icono('guardar', 16), ' ', t('ens.guardar', 'Guardar diseño')),
        h('label', { class: 'btn secundario archivo' }, t('ens.cargar', 'Cargar diseño…'),
          h('input', { type: 'file', accept: 'application/json,.json', onchange: async (e) => { const f = e.target.files[0]; if (f) { await app.cargarDiseno(JSON.parse(await f.text())); pintar(); } } })),
        h('button', { class: 'btn primario', onclick: () => app.go('pruebas') }, t('comun.siguiente', 'Siguiente'), ' →')));
  }

  return {
    async mount() {
      app.mostrarEscena(true, 'taller');
      cont = h('section', { class: 'pantalla compacta' });
      limpiar(app.panel).append(cont);
      await app.refrescarVista();
      app.view.setCascoAlpha(0.45);
      pintar();
    },
    unmount() { app.view.setCascoAlpha(1); }
  };
}
