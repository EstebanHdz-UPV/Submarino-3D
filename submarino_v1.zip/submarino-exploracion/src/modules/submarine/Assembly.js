import { computeStats } from './Stats.js';

/** El submarino armado: qué pieza (y material) hay en cada punto de montaje. */
export class Assembly {
  constructor(catalog, rules) {
    this.catalog = catalog; this.rules = rules; this.slots = rules.slots; this.piezas = {}; // slotId -> { partId, materialId }
  }
  slot(id) { return this.slots.find((s) => s.id === id) ?? null; }
  /** Coloca una pieza. Devuelve { ok, error? }. */
  place(slotId, partId, materialId) {
    const slot = this.slot(slotId), part = this.catalog.part(partId);
    if (!slot) return { ok: false, error: `Punto de montaje desconocido: ${slotId}` };
    if (!part) return { ok: false, error: `Pieza desconocida: ${partId}` };
    if (part.tipo !== slot.tipo) return { ok: false, error: `La pieza ${part.nombre} no es de tipo ${slot.tipo}.` };
    let mat = part.material ?? null;
    if (part.tipo === 'casco') {
      mat = materialId ?? part.materialPorDefecto;
      if (!part.materialesPermitidos.includes(mat)) return { ok: false, error: `Material no permitido para ${part.nombre}.` };
    }
    this.piezas[slotId] = { partId, materialId: mat };
    return { ok: true };
  }
  remove(slotId) { delete this.piezas[slotId]; }
  clear() { this.piezas = {}; }
  /** Pieza y material colocados en un punto de montaje. */
  get(slotId) {
    const it = this.piezas[slotId];
    if (!it) return null;
    return { part: this.catalog.part(it.partId), material: it.materialId ? this.catalog.material(it.materialId) : null };
  }
  stats(world, env) { return computeStats(this, world, env); }
  toJSON(nombre = 'diseno') { return { version: 1, nombre, piezas: { ...this.piezas } }; }
  load(json) {
    this.clear();
    const errs = [];
    for (const [slotId, it] of Object.entries(json.piezas ?? {})) {
      const r = this.place(slotId, it.partId, it.materialId);
      if (!r.ok) errs.push(r.error);
    }
    return errs;
  }
}
