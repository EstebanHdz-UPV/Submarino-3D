// Vista 3D del submarino armado: instancia las piezas en sus puntos de montaje y refleja la pose de la física.
import { SLog } from '../../core/SLog.js';
import { posicionSlot, geometriaCasco } from '../submarine/Stats.js';

/** Mundo físico (x adelante, y izquierda, z arriba) → Babylon (x derecha, y arriba, z adelante). */
export const aBabylon = (v) => new BABYLON.Vector3(-v[1], v[2], v[0]);

const TINTE = { 'aluminio-6061': [0.78, 0.8, 0.83], 'aluminio-7075': [0.7, 0.75, 0.82], 'acero-hy80': [0.38, 0.42, 0.48], 'titanio-6al4v': [0.6, 0.58, 0.66], 'compuesto-carbono': [0.1, 0.1, 0.12] };

export class AssemblyView {
  constructor(sm, loader) {
    this.sm = sm; this.loader = loader;
    this.root = new BABYLON.TransformNode('submarino', sm.scene);
    this.root.rotationQuaternion = BABYLON.Quaternion.Identity();
    this.nodos = new Map(); // slotId -> { clave, node, meshes, slot }
    this._m = new BABYLON.Matrix(); this.hullAlpha = 1; this._seq = 0; this.cabinaNode = null; this.foco = null;
    this._hatchAnimation = null;
    this._pickObserver = sm.scene.onPointerObservable.add((pi) => {
      if (pi.type !== BABYLON.PointerEventTypes.POINTERPICK) return;
      const picked = pi.pickInfo?.pickedMesh, hatch = picked?.metadata?.hatchRoot;
      if (hatch) this.toggleEscotilla(hatch);
    });
  }

  /** Reconstruye solo lo que cambió y reposiciona todo según la geometría del casco. */
  async actualizar(assembly, stats) {
    const seq = ++this._seq;
    const casco = stats.casco;
    const vivos = new Set();
    for (const slot of assembly.slots) {
      const it = assembly.get(slot.id);
      if (!it || !casco) continue;
      vivos.add(slot.id);
      const clave = `${it.part.id}|${it.material?.id ?? ''}|${casco.id}|${casco.radioM}x${casco.largoM}`;
      const prev = this.nodos.get(slot.id);
      if (prev && prev.clave === clave) { prev.slot = it.posRel ? { ...slot, posRel: it.posRel } : slot; continue; }
      if (prev) prev.node.dispose();
      const dims = this._dims(it.part, casco);
      const { node, meshes } = await this.loader.cargarPieza(it.part, dims, slot.id);
      if (seq !== this._seq) { node.dispose(); return; } // llegó una actualización más nueva
      node.parent = this.root;
      this._tinte(it, meshes);
      this.nodos.set(slot.id, { clave, node, meshes, slot: it.posRel ? { ...slot, posRel: it.posRel } : slot, part: it.part });
    }
    for (const [id, n] of [...this.nodos]) if (!vivos.has(id)) { n.node.dispose(); this.nodos.delete(id); }
    // posiciones (en el nodo contenedor: se suma el desfase de centrado calculado al ajustar)
    for (const [id, n] of this.nodos) {
      const p = posicionSlot(n.slot, casco);
      const b = new BABYLON.Vector3(-p[1], p[2], p[0]);
      if (!n.base) n.base = n.node.position.clone();
      n.node.position = n.base.add(b);
    }
    this.cabinaNode = this.nodos.get('cabina')?.node ?? null;
    this._visibilidad();
    this._focos(assembly, stats);
  }

  _dims(part, casco) {
    if (part.tipo === 'casco') { const { r, L } = geometriaCasco(casco); return { largo: L, ancho: 2 * r, alto: 2 * r }; }
    const v = part.visual ?? { largo: 0.5, ancho: 0.5, alto: 0.5 };
    const rRef = 0.6;
    const s = casco?.radioM ? Math.max(0.75, Math.min(1.4, casco.radioM / rRef)) : 1.0;
    // Las dimensiones se adaptan proporcionalmente al tamaño del casco seleccionado
    return {
      largo: Number((v.largo * (part.tipo === 'aletas' || part.tipo === 'cabina' ? s : Math.sqrt(s))).toFixed(3)),
      ancho: Number((v.ancho * s).toFixed(3)),
      alto: Number((v.alto * s).toFixed(3))
    };
  }

  _tinte(it, meshes) {
    if (it.part.tipo !== 'casco') return;
    const c = TINTE[it.material?.id]; if (!c) return;
    for (const m of meshes) {
      const mat = m.material; if (!mat) continue;
      if (mat.albedoColor) mat.albedoColor = new BABYLON.Color3(...c);
      else if (mat.diffuseColor) mat.diffuseColor = new BABYLON.Color3(...c);
    }
  }

  /** Alterna apertura/cierre de la escotilla con una animación de bisagra. */
  toggleEscotilla(node = this.nodos.get('escotilla')?.node) {
    const pivot = node?.metadata?.hatchPivot;
    if (!pivot) return false;
    const abierta = !node.metadata.hatchOpen;
    node.metadata.hatchOpen = abierta;
    const anim = new BABYLON.Animation('animacion-escotilla', 'rotation.z', 30, BABYLON.Animation.ANIMATIONTYPE_FLOAT, BABYLON.Animation.ANIMATIONLOOPMODE_CONSTANT);
    anim.setKeys([{ frame: 0, value: pivot.rotation.z }, { frame: 24, value: abierta ? 1.45 : 0 }]);
    this.sm.scene.stopAnimation(pivot);
    this.sm.scene.beginDirectAnimation(pivot, [anim], 0, 24, false, 1.15);
    return abierta;
  }

  /** Casco semitransparente para ver las piezas internas (pantalla de ensamblaje). */
  setCascoAlpha(a) { this.hullAlpha = a; this._visibilidad(); }
  _visibilidad() {
    const h = this.nodos.get('casco');
    if (h) for (const m of h.meshes) if (m.visibility !== undefined) m.visibility = this.hullAlpha;
    for (const [id, n] of this.nodos) if (!n.slot.externo && id !== 'casco') n.node.setEnabled(this.hullAlpha < 0.95);
  }

  _focos(assembly, stats) {
    const B = BABYLON;
    if (this.foco) { this.foco.dispose(); this.foco = null; }
    const f = this.nodos.get('focos');
    if (!f) return;
    const sp = new B.SpotLight('foco', B.Vector3.Zero(), new B.Vector3(0, -0.12, 1), 0.9, 2, this.sm.scene);
    sp.parent = f.node; sp.diffuse = new B.Color3(1, 0.97, 0.85); sp.range = stats.alcanceLuzM * 1.6;
    sp.intensity = 40 * (stats.alcanceLuzM / 10);
    this.foco = sp;
  }

  /** Posición/orientación a partir de la física (coordenadas del mundo físico). */
  aplicarPose(pos, R) {
    this.root.position = aBabylon(pos);
    // Ejes del cuerpo en Babylon: derecha = -izquierda, arriba, adelante. (FromLookDirectionLH invierte la proa.)
    const der = aBabylon(R[1]).scale(-1), arr = aBabylon(R[2]), ade = aBabylon(R[0]);
    BABYLON.Matrix.FromXYZAxesToRef(der, arr, ade, this._m);
    BABYLON.Quaternion.FromRotationMatrixToRef(this._m, this.root.rotationQuaternion);
  }
  ponerEn(profundidadM) { this.root.position.set(0, -profundidadM, 0); this.root.rotationQuaternion = BABYLON.Quaternion.Identity(); }
  get adelante() { return this.root.getDirection(BABYLON.Axis.Z); }
  get arriba() { return this.root.getDirection(BABYLON.Axis.Y); }
  posCabina() { return this.cabinaNode ? this.cabinaNode.getAbsolutePosition().clone() : this.root.position.clone(); }
  dispose() {
    if (this._pickObserver) this.sm.scene.onPointerObservable.remove(this._pickObserver);
    this.nodos.forEach((n) => n.node.dispose()); this.nodos.clear(); SLog.debug('AssemblyView', 'liberado');
  }
}
